const router = require("express").Router();
const controller = require('./users.controller');
const { guard } = require('../../helper');
const multerSetting = require("../../helper/multer").userImageUpload;

/*
 *  Register New User
 */
router.post(
    "/register",
    multerSetting,
    controller.register
);


 /*
  *  Get Profile
  */
router.get(
    "/",
    controller.get
);



 
router.put(
    "/:id",
    // multerSetting,
    
    controller.update
);

/*
 *  Delete  
 */
router.delete(
    "/:id",
    
    controller.delete
);


module.exports = router;