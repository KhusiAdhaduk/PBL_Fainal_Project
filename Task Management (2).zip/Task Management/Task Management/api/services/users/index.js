const usersRoutes = require('./users.routes');
const usersServices = require('./users.services');

module.exports = { usersRoutes, usersServices };
