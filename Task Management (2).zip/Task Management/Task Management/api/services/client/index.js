const clientRoutes = require('./client.routes');
const clientServices = require('./client.services');

module.exports = {clientRoutes , clientServices}