const projectRoutes = require('./project.routes');
const projectServices = require('./project.services');

module.exports = {projectRoutes , projectServices}