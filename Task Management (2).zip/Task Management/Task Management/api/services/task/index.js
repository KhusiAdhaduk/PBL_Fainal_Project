const taskRoutes = require('./task.routes');
const taskServices = require('./task.services');

module.exports = {taskRoutes , taskServices}