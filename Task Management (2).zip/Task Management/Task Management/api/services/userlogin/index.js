const userloginRoutes = require('./userlogin.routes');
const userloginServices = require('./userlogin.services');


module.exports = { userloginRoutes , userloginServices };